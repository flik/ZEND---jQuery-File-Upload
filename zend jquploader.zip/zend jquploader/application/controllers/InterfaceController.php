<?php
class InterfaceController extends Zend_Controller_Action
{
    public function init()
    {
	 	$this->_helper->layout()->setLayout('media');
        /* Initialize action controller here */
    }

    public function indexAction()
    {
         
    }
	
	
    public function mediaAction()
    {
	$this->_helper->layout()->setLayout('media');
        
    }
	
	function uploadjqAction()
	{ 
	$this->_helper->layout()->setLayout('media');
			Zend_Loader::loadClass('Upload',
									array(
										APPLICATION_PATH.'\vendors'
									)
			);

		$upload_handler = new Upload();
		
		header('Pragma: no-cache');
		header('Cache-Control: private, no-cache');
		header('Content-Disposition: inline; filename="files.json"');
		header('X-Content-Type-Options: nosniff');
		
		switch ($_SERVER['REQUEST_METHOD']) {
			case 'HEAD':
			case 'GET':
				$upload_handler->get();
				break;
			case 'POST':
				$upload_handler->post();
				break;
			case 'DELETE':
				$upload_handler->delete();
				break;
			case 'OPTIONS':
				break;
			default:
				header('HTTP/1.0 405 Method Not Allowed');
		}
 
		exit;
	
	}
	 
	

    
	

}









